package com.wipro.ApplicationFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
